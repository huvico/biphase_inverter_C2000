#include "Peripheral_Setup.h"
#include "Variables.h"
#include <math.h>

// ====================================================================================
// Declarações adicionais / auxiliares
// ====================================================================================

// Parâmetro para considerar que o módulo chegou a zero (parada completa)
static const float epsilon_modulo = 1e-3f;

// Funções auxiliares para controle de interrupções e PWM
void enable_control_interrupts(void);
void disable_control_interrupts(void);
void stop_all_pwms(void);
void start_all_pwms(void);

// Funções existentes
void initialization(void);      // initialize the MCU basic setup
void Calc_RPM(void);

// ====================================================================================
// Máquina de estados
// ====================================================================================

typedef enum
{
    INIT,
    RUNNING,
    STOPPING,
    ERROR,
    STOPPED,
    CALIBRATING,

} eSystemState;

typedef enum
{
    HI_Current,
    HI_DC_BUS_Voltage,
    Shutdown_command,
    turnOn_command,
    no_events,
    turn_calibration,

} eSystemEvent;

// ====================================================================================
// Funções auxiliares para PWM e interrupções
// ====================================================================================

void stop_all_pwms(void)
{
    // Zera duty cycle dos três PWMs e para os contadores
    EPwm1Regs.CMPA.bit.CMPA = 0;
    EPwm2Regs.CMPA.bit.CMPA = 0;
    EPwm3Regs.CMPA.bit.CMPA = 0;
  // Modo freeze/stop do contador (CTRMODE = 3)
    EPwm1Regs.TBCTL.bit.CTRMODE = 3;
    EPwm2Regs.TBCTL.bit.CTRMODE = 3;
    EPwm3Regs.TBCTL.bit.CTRMODE = 3;
}

void start_all_pwms(void)
{
    // Retoma contadores dos ePWMs em modo up-down (2)
    EPwm1Regs.TBCTL.bit.CTRMODE = 2;
    EPwm2Regs.TBCTL.bit.CTRMODE = 2;
    EPwm3Regs.TBCTL.bit.CTRMODE = 2;
}

void enable_control_interrupts(void)
{
    EALLOW;
    // Habilita interrupção ADC A1 e TIMER0 no PIE group 1
    PieCtrlRegs.PIEIER1.bit.INTx1 = 1; // ADCA1_INT
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1; // TIMER0_INT
    EDIS;
  // Garante que o Timer0 está habilitado
    CpuTimer0Regs.TCR.all = 0x4001; // TSS=0, TIE=1
  // Habilita interrupções globais e em tempo real
    EINT;
    ERTM;
}

void disable_control_interrupts(void)
{
    // Desabilita interrupções globais
    DINT;
  EALLOW;
    // Desabilita interrupções específicas no PIE group 1
    PieCtrlRegs.PIEIER1.bit.INTx1 = 0; // ADCA1_INT
    PieCtrlRegs.PIEIER1.bit.INTx7 = 0; // TIMER0_INT
    EDIS;
  // Para Timer0
    CpuTimer0Regs.TCR.bit.TSS = 1; // Stop Timer0
}

// ====================================================================================
// Event handlers / estados
// ====================================================================================

eSystemState ini(void)
{
    return INIT;
}

eSystemState end_init_goto_ON(void)
{
    // Habilita interrupções e PWM para iniciar controle
    start_all_pwms();
    enable_control_interrupts();
  DCL_resetRefgen(&rgen);
    DCL_setRefgen(&rgen,
                  0.707f,
                  2.0f*M_PI*60.0f,
                  w_nom,
                  START_TIME_MACHINE,
                  TS_RefGen);
  return RUNNING;
}

eSystemState goto_OFF(void) // shutdown PWM, rampa para zero
{
    // Ref de tensão vai para zero com rampa
    DCL_setRefgen(&rgen,
                  0.0f,
                  2.0f*M_PI*60.0f,
                  0.0f,
                  START_TIME_MACHINE/4.0f,
                  TS_RefGen);
  // O PWM será desligado de fato na transição STOPPING -> STOPPED
    return STOPPING;
}

eSystemState goto_error(void)
{
    // Desliga PWM imediatamente
    stop_all_pwms();
  // Desabilita interrupções
    disable_control_interrupts();
  // Aqui poderiam ser setados flags de erro / alarmes
    return ERROR;
}

eSystemState goto_STOPPED(void)
{
    // STOPPED = controle pausado + PWM desligado
    disable_control_interrupts();
    stop_all_pwms();
  adc1    = 0.0f;
    adc2    = 0.0f;
    V_alpha = 0.0f;
    V_beta  = 0.0f;
  return STOPPED;
}

eSystemState goto_CALIBRATION(void)
{
    // Liga PWM (se necessário) e habilita interrupções para executar a calibração
    start_all_pwms();
    enable_control_interrupts();
  DCL_resetRefgen(&rgen);
  return CALIBRATING;
}

// ====================================================================================
// Leitura de eventos
// ====================================================================================

eSystemEvent ReadEvent(void)
{
    if (adc1 > Imax || adc2 > Imax || adc1 < -Imax || adc2 < -Imax) {
        return HI_Current;
    }
  if (turn_off_command == 1) {
        DCL_setRefgen(&rgen,
                      0.0f,
                      2.0f*M_PI*60.0f,
                      0.0f,
                      START_TIME_MACHINE/2.0f,
                      Ts);      // aqui você está usando Ts, pode trocar por TS_RefGen se quiser
        turn_off_command = 0;
        return Shutdown_command;
    }
  if (turn_on_command == 1) {
        // Agora NÃO habilitamos as interrupções e PWM aqui.
        // Apenas sinalizamos o evento. A máquina de estados
        // só aceitará turnOn quando estiver em STOPPED.
        turn_on_command = 0;
        return turnOn_command;
    }
  if (set_new_ref == 1) {
        DCL_setRefgen(&rgen,
                      new_amp,
                      2.0f*M_PI*60.0f,
                      2.0f*M_PI*new_f,
                      START_TIME_MACHINE/2.0f,
                      Ts);      // idem comentário acima
        set_new_ref = 0;
        return no_events;
    }
  /*
    if (turnon_calibration == 1) {
        turnon_calibration = 0;
        return turn_calibration;
    }
    */
  return no_events;
}

eSystemEvent  eNewEvent;
eSystemState  eNextState = INIT;

// ====================================================================================
// main
// ====================================================================================

int main(void)
{
    while (1)
    {
        // Read system Events
        eNewEvent = ReadEvent();
      switch (eNextState)
        {
        case INIT:
        {
            initialization();
            Setup_GPIO();
            Setup_PWM();
            Setup_ADC();
            Setup_eQEP();
          GpioDataRegs.GPASET.bit.GPIO6 = 1;
          w_nom    = 2.0f*M_PI*60.0f;
            TS_RefGen = Ts;
          DCL_resetRefgen(&rgen);
            DCL_setRefgen(&rgen,
                          0.707f,
                          2.0f*M_PI*60.0f,
                          w_nom,
                          START_TIME_MACHINE,
                          TS_RefGen);
          // Após init, vamos para STOPPED com PWM realmente desligado
            eNextState = goto_STOPPED();
        }
        break;
      case RUNNING:
        {
            if (HI_Current == eNewEvent) {
                eNextState = goto_error();
            }
            if (Shutdown_command == eNewEvent) {
                eNextState = goto_OFF();
            }
        }
        break;
      case STOPPING:
        {
            // Não aceitamos turnOn aqui.
            // O ligamento só será aceito em STOPPED (parada completa garantida).
          // Verifica se módulo (tensão de saída) está praticamente zero
            if (modulo < epsilon_modulo) {
                eNextState = goto_STOPPED();
            }
        }
        break;
      case ERROR:
        {
            // Em estado de erro, só aceitaremos turnOn para rearmar explicitamente o sistema
            if (turnOn_command == eNewEvent) {
                eNextState = end_init_goto_ON();
            }
        }
        break;
      /*
        case CALIBRATING:
        {
            if (turnOn_command == eNewEvent) {
                eNextState = end_init_goto_ON();
            }
            if (Shutdown_command == eNewEvent) {
                eNextState = goto_OFF();
            }
          offset1  = 0.0f;
            offset2  = 0.0f;
            index_cal = 0;
            while (index_cal < 20)
            {
                DELAY_US(100000);
                offset1 = offset1 + AdcaResultRegs.ADCRESULT1;
                offset2 = offset2 + AdcaResultRegs.ADCRESULT2;
                index_cal = index_cal + 1;
            }
          offset1 = offset1/20.0f;
            offset2 = offset2/20.0f;
          calibration = 1;
            eNextState  = goto_OFF();
        }
        break;
        */
      case STOPPED:
        {
            // Só aceitamos turnOn quando realmente estamos em STOPPED,
            // ou seja, PWM parado e módulo ~0.
            if (turnOn_command == eNewEvent) {
                eNextState = end_init_goto_ON();
            }
            if (turn_calibration == eNewEvent) {
                eNextState = goto_CALIBRATION();
            }
        }
        break;
      default:
            break;
        }
    }
  return 0;
}

// ====================================================================================
// ISR ADC
// ====================================================================================

__interrupt void isr_adc(void)
{
    // Load ADC results
    adc1 = sensor_1*(float)(AdcaResultRegs.ADCRESULT1 - offset1)/4096.0f;
    adc2 = sensor_2*(float)(AdcaResultRegs.ADCRESULT2 - offset2)/4096.0f;
    adc3 = 0.17350095166015625f * ((float)AdcaResultRegs.ADCRESULT0);
  AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;
    PieCtrlRegs.PIEACK.all            = PIEACK_GROUP1;
}

// ====================================================================================
// ISR Timer0
// ====================================================================================

__interrupt void isr_cpu_timer0(void)
{
    // Controle de índice do buffer, evitando acesso fora do limite
    if (index >= (BUFFER_PLOT_SIZE - 1U)) {
        index = 0U;
      // Atualiza média RMS aproximada
        avg_plot  = 0.95f*avg_plot  + 0.05f*sqrtf(sum_avg  /(float)BUFFER_PLOT_SIZE);
        sum_avg   = 0.0f;
      avg_plot2 = 0.95f*avg_plot2 + 0.05f*sqrtf(sum_avg2 /(float)BUFFER_PLOT_SIZE);
        sum_avg2  = 0.0f;
      avg_plot3 = 0.95f*avg_plot3 + 0.05f*sqrtf(sum_avg3 /(float)BUFFER_PLOT_SIZE);
        sum_avg3  = 0.0f;
    } else {
        index++;
    }
  // Atualiza buffers de plotagem e somas de quadrados
    plot[index]  = *p_adc;
    sum_avg      = sum_avg  + ((float)plot[index])*((float)plot[index]);
  plot2[index] = *p_adc2;
    sum_avg2     = sum_avg2 + ((float)plot2[index])*((float)plot2[index]);
  plot3[index] = *p_adc3;
    sum_avg3     = sum_avg3 + ((float)plot3[index])*((float)plot3[index]);
  // Calcula novas referências de tensão
    run_Refgen(&rgen, &V_alpha, &V_beta);
  modulo     = sqrtf(V_alpha*V_alpha + V_beta*V_beta);
    frequencia = rgen.freq;
    teta       = rgen.theta;
  // SVPWM bifásico assimétrico
    svpwm_bi(&teta, &V_alpha, &V_beta, &wma, &wmb, &wmc);
  // Atualiza o duty cycle
    EPwm1Regs.CMPA.bit.CMPA = wma*SWITCH_PERIOD; // fase main_W
    EPwm2Regs.CMPA.bit.CMPA = wmb*SWITCH_PERIOD; // fase comum_V
    EPwm3Regs.CMPA.bit.CMPA = wmc*SWITCH_PERIOD; // fase aux_U
  PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

// ====================================================================================
// Initialization
// ====================================================================================

void initialization(void)
{
    InitSysCtrl();  // Initialize System Control
    DINT;           // Disable CPU interrupts
    InitPieCtrl();  // Initialize the PIE control registers to default state
    IER = 0x0000;   // Disable CPU interrupts
    IFR = 0x0000;   // Clear all CPU interrupt flags
  EALLOW;
    CpuSysRegs.PCLKCR0.bit.CPUTIMER0 = 1;   // Enable CPUtimer clock
    EDIS;
  InitPieVectTable();                     // Initialize the PIE vector table
    IpcRegs.IPCCLR.all = 0xFFFFFFFF;        // Clear IPC Flags
  EALLOW;
    PieVectTable.TIMER0_INT = &isr_cpu_timer0; // endereço da função de interrupção
    PieVectTable.ADCA1_INT  = &isr_adc;        // função de interrupção ADC
    EDIS;
  IER |= M_INT1;
  InitCpuTimers();
    // Escolhe o timer, frequência em MHz e período em us
    ConfigCpuTimer(&CpuTimer0, 200, Ts*1000000.0f);
    CpuTimer0Regs.TCR.all = 0x4001; // Habilita a interrupção do timer (TSS=0, TIE=1)
}

// ====================================================================================
// Calc_RPM
// ====================================================================================

void Calc_RPM(void)
{
    if (EQep1Regs.QFLG.bit.UTO) {          // Unit Timeout event
        new_pos = EQep1Regs.QPOSLAT;       // Latched POSCNT value
      delta_pos = (new_pos >= old_pos) ?
                    (new_pos - old_pos) :
                    ((eQEP_max_count - old_pos) + new_pos);
      old_pos = new_pos;
        EQep1Regs.QCLR.bit.UTO = 1;
    }
  rpm = ((float)(delta_pos))*(float)(60.0f/8.0f);
}