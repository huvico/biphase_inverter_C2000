/*
 * Peripheral_Setup.c
 *
 * Configuração de periféricos do F28379D:
 *   - GPIO (PWM, eQEP, GPIO6 para debug)
 *   - ePWM1..3 (frequência, dead-time, ações, trigger para ADC)
 *   - ADC (grupo A, canais de corrente/tensão)
 *   - DAC (opcional, atualmente comentado)
 *   - eQEP1 (medição de posição/velocidade)
 *
 * Criado em: 17 de mar de 2021
 * Autor: Hudson
 */

#include "Peripheral_Setup.h"

// ============================================================================
// Configuração de GPIO
// ============================================================================
//
// PWM1-3:
//   GPIO0  -> ePWM1A
//   GPIO1  -> ePWM1B
//   GPIO2  -> ePWM2A
//   GPIO3  -> ePWM2B
//   GPIO4  -> ePWM3A
//   GPIO5  -> ePWM3B
//
// GPIO6:
//   Saída digital para medição de tempo/debug.
//
// eQEP1:
//   GPIO10 -> EQEP1A (entrada de quadratura)
// ============================================================================

void Setup_GPIO(void)
{
    EALLOW;
  // ------------------------------------------------------------------------
    // PWM1-3: multiplexação dos pinos
    // ------------------------------------------------------------------------
  // Seleciona função GPIO (não alternativo) no grupo A (GMUX = 0)
    GpioCtrlRegs.GPAGMUX1.bit.GPIO0 = 0;
    GpioCtrlRegs.GPAGMUX1.bit.GPIO1 = 0;
    GpioCtrlRegs.GPAGMUX1.bit.GPIO2 = 0;
    GpioCtrlRegs.GPAGMUX1.bit.GPIO3 = 0;
    GpioCtrlRegs.GPAGMUX1.bit.GPIO4 = 0;
    GpioCtrlRegs.GPAGMUX1.bit.GPIO5 = 0;
  // Mux para função ePWM
    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1;  // GPIO0 = PWM1A
    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 1;  // GPIO1 = PWM1B
    GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 1;  // GPIO2 = PWM2A
    GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 1;  // GPIO3 = PWM2B
    GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 1;  // GPIO4 = PWM3A
    GpioCtrlRegs.GPAMUX1.bit.GPIO5 = 1;  // GPIO5 = PWM3B
  // Pull-ups desabilitados (1 = disable)
    GpioCtrlRegs.GPAPUD.bit.GPIO0 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO1 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO2 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO3 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO4 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO5 = 1;
  // ------------------------------------------------------------------------
    // GPIO6: saída digital para debug / medição de tempo
    // ------------------------------------------------------------------------
  GpioCtrlRegs.GPAPUD.bit.GPIO6 = 0;   // Enable pull-up em GPIO6 (PIN 80, J8)
    GpioDataRegs.GPASET.bit.GPIO6 = 1;   // Inicializa latch de saída em 1
    GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 0;  // Função regular GPIO
    GpioCtrlRegs.GPADIR.bit.GPIO6 = 1;   // GPIO6 como saída
  // ------------------------------------------------------------------------
    // eQEP1: configuração de GPIO10 como EQEP1A
    // ------------------------------------------------------------------------
  GpioCtrlRegs.GPAPUD.bit.GPIO10   = 1; // Disable pull-up em GPIO10
    GpioCtrlRegs.GPAQSEL1.bit.GPIO10 = 0; // Sincroniza GPIO10 com SYSCLK
    GpioCtrlRegs.GPAGMUX1.bit.GPIO10 = 1; // GMUX para função EQEP1
    GpioCtrlRegs.GPAMUX1.bit.GPIO10  = 1; // MUX para EQEP1A
  /*
    // Exemplo alternativo com múltiplos pinos de eQEP1:
    // GPIO20..23 como EQEP1A, EQEP1B, EQEP1S, EQEP1I
  GpioCtrlRegs.GPAPUD.bit.GPIO20 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO21 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO22 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO23 = 1;
  GpioCtrlRegs.GPAQSEL2.bit.GPIO20 = 0;
    GpioCtrlRegs.GPAQSEL2.bit.GPIO21 = 0;
    GpioCtrlRegs.GPAQSEL2.bit.GPIO22 = 0;
    GpioCtrlRegs.GPAQSEL2.bit.GPIO23 = 0;
  GpioCtrlRegs.GPAGMUX2.bit.GPIO20 = 0;
    GpioCtrlRegs.GPAGMUX2.bit.GPIO21 = 0;
    GpioCtrlRegs.GPAGMUX2.bit.GPIO22 = 0;
    GpioCtrlRegs.GPAGMUX2.bit.GPIO23 = 0;
  GpioCtrlRegs.GPAMUX2.bit.GPIO20 = 1;
    GpioCtrlRegs.GPAMUX2.bit.GPIO21 = 1;
    GpioCtrlRegs.GPAMUX2.bit.GPIO22 = 1;
    GpioCtrlRegs.GPAMUX2.bit.GPIO23 = 1;
    */
  EDIS;
}

// ============================================================================
// Configuração de ePWM1..3
// ============================================================================
//
// Todos os canais são configurados em:
//   - Modo up-down (simétrico)
//   - Dead-time com polaridade ativa complementar
//   - CMPA inicial em 50% (SWITCH_PERIOD/2)
//   - SOCA em ePWM1 (disparo para ADC)
// ============================================================================

void Setup_PWM(void)
{
    EALLOW;
  // Desabilita sincronização de TBCLKs enquanto configura ePWMs
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0;
  // Habilita clocks dos módulos ePWM
    CpuSysRegs.PCLKCR2.bit.EPWM1 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM2 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM3 = 1;
  // ------------------------------------------------------------------------
    // ePWM1
    // ------------------------------------------------------------------------
    EPwm1Regs.TBPRD = SWITCH_PERIOD;              // Período do timer
    EPwm1Regs.CMPA.bit.CMPA = EPwm1Regs.TBPRD >> 1; // Duty inicial 50%
    EPwm1Regs.TBPHS.bit.TBPHS = 0;                // Fase zero
    EPwm1Regs.TBCTR = 0x0000;                     // Zera contador
  EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // Modo up-down
    EPwm1Regs.TBCTL.bit.PHSEN   = TB_DISABLE;      // Desabilita carga de fase
    EPwm1Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;       // Divisor de clock alto
    EPwm1Regs.TBCTL.bit.CLKDIV    = TB_DIV1;       // Divisor de clock baixo
    EPwm1Regs.TBCTL.bit.SYNCOSEL  = TB_CTR_ZERO;   // Gera sync quando CTR=0
  // Shadow mode e momento de carga do CMPA/B
    EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD; // Carrega em zero e período
    EPwm1Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm1Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;
  // Ações em compare para saída A (PWM1A)
    EPwm1Regs.AQCTLA.bit.PRD = AQ_NO_ACTION;
    EPwm1Regs.AQCTLA.bit.ZRO = AQ_NO_ACTION;
    EPwm1Regs.AQCTLA.bit.CAU = AQ_CLEAR;
    EPwm1Regs.AQCTLA.bit.CAD = AQ_SET;
  // Dead-band: saída complementar com dead-time simétrico
    EPwm1Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
    EPwm1Regs.DBCTL.bit.POLSEL   = DB_ACTV_HIC;   // Complementar
    EPwm1Regs.DBFED.bit.DBFED    = FALL_TIME;     // Falling edge delay
    EPwm1Regs.DBRED.bit.DBRED    = RISE_TIME;     // Rising edge delay
  // Trigger para ADC (SOCA)
    EPwm1Regs.ETSEL.bit.SOCAEN = 1;                // Habilita SOCA
    EPwm1Regs.ETSEL.bit.SOCASEL = ET_CTR_PRDZERO;  // Dispara em ZERO e PRD
    EPwm1Regs.ETPS.bit.SOCAPRD  = ET_1ST;          // Em todo evento (2x Fpwm)
  // ------------------------------------------------------------------------
    // ePWM2
    // ------------------------------------------------------------------------
    EPwm2Regs.TBPRD = SWITCH_PERIOD;
    EPwm2Regs.CMPA.bit.CMPA = EPwm2Regs.TBPRD >> 1;
    EPwm2Regs.TBPHS.bit.TBPHS = 0;
    EPwm2Regs.TBCTR = 0x0000;
  EPwm2Regs.TBCTL.bit.CTRMODE   = TB_COUNT_UPDOWN;
    EPwm2Regs.TBCTL.bit.PHSEN     = TB_DISABLE;
    EPwm2Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;
    EPwm2Regs.TBCTL.bit.CLKDIV    = TB_DIV1;
    EPwm2Regs.TBCTL.bit.SYNCOSEL  = TB_CTR_ZERO;
  EPwm2Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm2Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
    EPwm2Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm2Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;
  EPwm2Regs.AQCTLA.bit.PRD = AQ_NO_ACTION;
    EPwm2Regs.AQCTLA.bit.ZRO = AQ_NO_ACTION;
    EPwm2Regs.AQCTLA.bit.CAU = AQ_CLEAR;
    EPwm2Regs.AQCTLA.bit.CAD = AQ_SET;
  EPwm2Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
    EPwm2Regs.DBCTL.bit.POLSEL   = DB_ACTV_HIC;
    EPwm2Regs.DBFED.bit.DBFED    = FALL_TIME;
    EPwm2Regs.DBRED.bit.DBRED    = RISE_TIME;
  // ------------------------------------------------------------------------
    // ePWM3
    // ------------------------------------------------------------------------
    EPwm3Regs.TBPRD = SWITCH_PERIOD;
    EPwm3Regs.CMPA.bit.CMPA = EPwm3Regs.TBPRD >> 1;
    EPwm3Regs.TBPHS.bit.TBPHS = 0;
    EPwm3Regs.TBCTR = 0x0000;
  EPwm3Regs.TBCTL.bit.CTRMODE   = TB_COUNT_UPDOWN;
    EPwm3Regs.TBCTL.bit.PHSEN     = TB_DISABLE;
    EPwm3Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;
    EPwm3Regs.TBCTL.bit.CLKDIV    = TB_DIV1;
    EPwm3Regs.TBCTL.bit.SYNCOSEL  = TB_CTR_ZERO;
  EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
    EPwm3Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm3Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;
  EPwm3Regs.AQCTLA.bit.PRD = AQ_NO_ACTION;
    EPwm3Regs.AQCTLA.bit.ZRO = AQ_NO_ACTION;
    EPwm3Regs.AQCTLA.bit.CAU = AQ_CLEAR;
    EPwm3Regs.AQCTLA.bit.CAD = AQ_SET;
  EPwm3Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
    EPwm3Regs.DBCTL.bit.POLSEL   = DB_ACTV_HIC;
    EPwm3Regs.DBFED.bit.DBFED    = FALL_TIME;
    EPwm3Regs.DBRED.bit.DBRED    = RISE_TIME;
  // Reabilita sincronização de TBCLKs
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
  EDIS;
}

// ============================================================================
// Configuração do ADC (Grupo A)
// ============================================================================
//
// - Habilita ADC-A
// - Configura resolução 12 bits, modo single-ended
// - Usa ePWM1 SOCA como trigger
// - Canais usados (Adca):
//   - SOC0 -> CH3 (pino A3 / pin26 J3)
//   - SOC1 -> CH4 (corrente 1, pino A4 / pin69 J7)
//   - SOC2 -> CH5 (corrente 2, pino A5 / pin66 J7)
// - INT1 gerado ao final de SOC2
// ============================================================================

void Setup_ADC(void)
{
    Uint16 acqps;
  // Janela mínima de aquisição (em SYSCLKs) baseada na resolução
    if (ADC_RESOLUTION_12BIT == AdcaRegs.ADCCTL2.bit.RESOLUTION)
        acqps = 42;     // 75 ns (ajustado a partir de 14)
    else
        acqps = 63;     // ~320 ns
  EALLOW;
  // Grupo A
    CpuSysRegs.PCLKCR13.bit.ADC_A = 1;                // Clock ADC A
    AdcaRegs.ADCCTL2.bit.PRESCALE = 6;                // Define ADCCLK
    AdcSetMode(ADC_ADCA, ADC_RESOLUTION_12BIT, ADC_SIGNALMODE_SINGLE);
    AdcaRegs.ADCCTL1.bit.INTPULSEPOS = 1;             // Pulso de interrupção próximo ao fim da conversão
    AdcaRegs.ADCCTL1.bit.ADCPWDNZ    = 1;             // Liga ADC A
  DELAY_US(1000);                                   // Tempo de power-up
  /*
     * Mapeamento dos canais (Adca):
     *  CH2 -> PIN29 J3 (não usar: ligado a VrefHIB 3V)
     *  CH3 -> PIN26 J3 (Vdc, por ex.)
     *  CH4 -> PIN69 J7 (corrente 1)
     *  CH5 -> PIN66 J7 (corrente 2)
     */
  // SOC0: canal 3
    AdcaRegs.ADCSOC0CTL.bit.CHSEL   = 3;
    AdcaRegs.ADCSOC0CTL.bit.ACQPS   = acqps;
    AdcaRegs.ADCSOC0CTL.bit.TRIGSEL = TRIG_SEL_ePWM1_SOCA;
  // SOC1: canal 4
    AdcaRegs.ADCSOC1CTL.bit.CHSEL   = 4;
    AdcaRegs.ADCSOC1CTL.bit.ACQPS   = acqps;
    AdcaRegs.ADCSOC1CTL.bit.TRIGSEL = TRIG_SEL_ePWM1_SOCA;
  // SOC2: canal 5
    AdcaRegs.ADCSOC2CTL.bit.CHSEL   = 5;
    AdcaRegs.ADCSOC2CTL.bit.ACQPS   = acqps;
    AdcaRegs.ADCSOC2CTL.bit.TRIGSEL = TRIG_SEL_ePWM1_SOCA;
  // INT1 ao final de SOC2 (índice 2)
    AdcaRegs.ADCINTSEL1N2.bit.INT1SEL = 0x02;
    AdcaRegs.ADCINTSEL1N2.bit.INT1E   = 1;    // Habilita INT1
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;    // Limpa flag INT1
  /*
    // Configuração de grupos B e C (mantida comentada para referência futura):
  // Grupo B
    CpuSysRegs.PCLKCR13.bit.ADC_B = 1;
    AdcbRegs.ADCCTL2.bit.PRESCALE = 6;
    AdcSetMode(ADC_ADCB, ADC_RESOLUTION_12BIT, ADC_SIGNALMODE_SINGLE);
    AdcbRegs.ADCCTL1.bit.INTPULSEPOS = 1;
    AdcbRegs.ADCCTL1.bit.ADCPWDNZ    = 1;
    DELAY_US(1000);
  // Grupo C
    CpuSysRegs.PCLKCR13.bit.ADC_C = 1;
    AdccRegs.ADCCTL2.bit.PRESCALE = 1;
    AdcSetMode(ADC_ADCC, ADC_RESOLUTION_12BIT, ADC_SIGNALMODE_SINGLE);
    AdccRegs.ADCCTL1.bit.INTPULSEPOS = 1;
    AdccRegs.ADCCTL1.bit.ADCPWDNZ    = 1;
    DELAY_US(1000);
    */
  EDIS;
}

// ============================================================================
// Configuração do DAC (opcional – atualmente comentado)
// ============================================================================

void Setup_DAC(void)
{
    /*
    EALLOW;
  CpuSysRegs.PCLKCR16.bit.DAC_A = 1;    // Habilita clock do DAC A
    DacaRegs.DACCTL.bit.SYNCSEL   = 0x00; // Sincronização por software / PWM
    DacaRegs.DACCTL.bit.LOADMODE  = 0x01; // Load on next SYSCLK ou trigger
    DacaRegs.DACCTL.bit.DACREFSEL = 0x01; // Referência 3.0V (VrefHi)
    DacaRegs.DACVALS.bit.DACVALS  = 0;    // Valor inicial (12 bits)
    DacaRegs.DACOUTEN.bit.DACOUTEN = 1;   // Habilita saída do DAC
    DacaRegs.DACLOCK.all          = 0x00;
  EDIS;
    */
}

// ============================================================================
// Configuração do eQEP1
// ============================================================================
//
// - Up count mode (freq. measurement)
// - 1x resolução (conta apenas borda de subida)
// - Latch em unit timeout
// - Unit Timer habilitado
// - QPOSMAX = 0xFFFFFFFF
// ============================================================================

void Setup_eQEP(void)
{
    EALLOW;
    CpuSysRegs.PCLKCR4.bit.EQEP1 = 1;   // Habilita clock do EQEP1
    EDIS;
  // Fonte de contagem: modo 2 (por datasheet: normalmente direction count)
    EQep1Regs.QDECCTL.bit.QSRC = 2;
  // XCR = 0 -> 1x resolução (conta apenas borda de subida)
    EQep1Regs.QDECCTL.bit.XCR = 0;
  // FREE_SOFT = 2 -> contador não é afetado por emulação/suspend
    EQep1Regs.QEPCTL.bit.FREE_SOFT = 2;
  // Latch na condição de unit timeout
    EQep1Regs.QEPCTL.bit.QCLM = 1;
  // Habilita Unit Timer
    EQep1Regs.QEPCTL.bit.UTE = 1;
  // Valor máximo de posição (para wrap-around controlado)
    EQep1Regs.QPOSMAX = 0xFFFFFFFF;
  // Habilita QEP
    EQep1Regs.QEPCTL.bit.QPEN = 1;
  // Habilita módulo de captura
    EQep1Regs.QCAPCTL.bit.CEN = 1;
  /*
    // Versão alternativa com parâmetros adicionais:
    EQep1Regs.QDECCTL.bit.QSRC = 2;
    EQep1Regs.QDECCTL.bit.XCR  = 0;
    EQep1Regs.QEPCTL.bit.FREE_SOFT = 2;
    EQep1Regs.QEPCTL.bit.QCLM      = 1;
    EQep1Regs.QEPCTL.bit.UTE       = 1;
    EQep1Regs.QPOSMAX              = eQEP_max_count;
    EQep1Regs.QEPCTL.bit.QPEN      = 1;
    EQep1Regs.QCAPCTL.bit.CEN      = 1;
    // EQep1Regs.QDECCTL.bit.QIP   = 1;  // Inversão de polaridade de QEPS (se necessário)
    // EQep1Regs.QEPCTL.bit.IEL    = 1;  // Latch em evento de índice
    */
}