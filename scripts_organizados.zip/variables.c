#include "Variables.h"
#include "Peripheral_Setup.h"
#include <math.h>

// ============================================================================
// Objetos de controle digital
// ============================================================================

DCL_REFGEN rgen = DCL_REFGEN_DEFAULTS;

// Ts: período de amostragem do Timer0 (ligado à taxa de controle/plot)
// Expressão original: Ts = 2.0/60.0/(float)BUFFER_plot_size;
float Ts      = 2.0f / 60.0f / (float)BUFFER_PLOT_SIZE;

// TS_RefGen: período de amostragem do RefGen
// Expressão original: TS_RefGen = 0.5/(200000000.0/(4.0*(float)SWITCH_PERIOD));
float TS_RefGen = 0.5f / (200000000.0f / (4.0f * (float)SWITCH_PERIOD));

// ============================================================================
// Medidas de corrente e tensão
// ============================================================================

float adc1    = 0.0f;   // I_alpha
float adc2    = 0.0f;   // I_beta
float adc3    = 0.0f;   // V_dc

float sensor_1 = 45.371f;
float sensor_2 = 44.62f;

float Imax     = 30.0f;

float offset1  = 2290.0f;
float offset2  = 2290.0f;
float offset3  = 0.0f;

// ============================================================================
// Referências e parâmetros de controle
// ============================================================================

float w_nom   = 0.0f;

float new_amp = 0.5f;
float new_f   = 60.0f;

float V_alpha = 0.0f;
float V_beta  = 0.0f;
float teta    = 0.0f;

float modulo      = 0.0f;
float frequencia  = 0.0f;
float wma         = 0.0f;
float wmb         = 0.0f;
float wmc         = 0.0f;

// ============================================================================
// Variáveis de estado lógico / comandos
// ============================================================================

unsigned char send               = 0;
unsigned char turn_off_command   = 0;
unsigned char turn_on_command    = 0;
unsigned char set_new_ref        = 0;
unsigned char calibration        = 1;
unsigned char turnon_calibration = 0;

// ============================================================================
// Cálculo de velocidade (eQEP)
// ============================================================================

unsigned long delta_pos = 0;
unsigned int  new_pos   = 0;
unsigned int  old_pos   = 0;

float rpm       = 0.0f;
float avg_rpm   = 0.0f;
float index_rpm = 0.0f;
float period    = 0.0f;

// ============================================================================
// Plotagem / diagnósticos
// ============================================================================

float *p_adc  = &adc1;
float *p_adc2 = &adc2;
float *p_adc3 = &adc3;

float plot[BUFFER_PLOT_SIZE]  = {0.0f};
float plot2[BUFFER_PLOT_SIZE] = {0.0f};
float plot3[BUFFER_PLOT_SIZE] = {0.0f};

float avg_plot  = 0.0f;
float sum_avg   = 0.0f;

float avg_plot2 = 0.0f;
float sum_avg2  = 0.0f;

float avg_plot3 = 0.0f;
float sum_avg3  = 0.0f;

uint32_t index = 0U;

// ============================================================================
// Calibração de correntes
// ============================================================================

int index_cal  = 0;
int flag_Ra_OK = 0;
int flag_Rb_OK = 1;
int flag_AC    = 0;

float ra_alpha[CAL_POINTS] = {0.0f};
float ra_beta[CAL_POINTS]  = {0.0f};
float ia_cc[CAL_POINTS]    = {0.0f};
float ib_cc[CAL_POINTS]    = {0.0f};

float v_ref = 0.03f;
float v_bus = 178.0f;