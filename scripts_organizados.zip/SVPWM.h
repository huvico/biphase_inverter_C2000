/*
 * SVPWM.h
 *
 * Descrição:
 *   Rotinas de:
 *     - Space Vector PWM bifásico assimétrico (motor bifásico / monofásico assimétrico)
 *     - Geração de referência senoidal (RefGen) em eixo alfa/beta
 *
 * Observação:
 *   O SVPWM implementado aqui trabalha com duas componentes em quadratura (V_alpha, V_beta),
 *   mas considerando um espaço vetorial assimétrico, adequado para controle de motor bifásico.
 *
 * Criado em: 28 de abr de 2022
 * Autor: Hudson
 */

#ifndef SVPWM_H_
#define SVPWM_H_

#include <math.h>
#include <stdint.h>

// ============================================================================
// Tipos auxiliares
// ============================================================================

// Compatibilidade com tipo de ponto flutuante usado no F28379D
typedef float float32_t;

// Status da rampa de amplitude/frequência do gerador de referência
typedef enum
{
    INCREASING,   // Rampa de amplitude/frequência em aumento
    DOWNING,      // Rampa de amplitude/frequência em redução
    FINISHED,     // Rampa concluída (amplitude/freq atingiram valor alvo)
    // CALIBRATING_ALPHA,
    // CALIBRATING_BETA,
} incStatus;

// ============================================================================
// Protótipos de funções públicas
// ============================================================================

// SVPWM bifásico assimétrico
// Entrada:
//   - theta       : ponteiro para ângulo (rad) de referência
//   - V_alpha     : ponteiro para componente alfa da tensão
//   - V_beta      : ponteiro para componente beta da tensão
// Saída:
//   - wma, wmb, wmc: ponteiros para fatores de modulação das fases (0..1)
// Observação: a implementação fica em SVPWM.c
void svpwm_bi(float *theta,
              float *V_alpha,
              float *V_beta,
              float *wma,
              float *wmb,
              float *wmc);

// SVPWM trifásico tradicional (se utilizado em outro contexto)
// (mantido aqui para compatibilidade com versões anteriores do projeto)
void svpwm(float *theta,
           float *V_alpha,
           float *V_beta,
           float *wma,
           float *wmb,
           float *wmc);

// Geração de sinal senoidal (pode ser usada para testes)
// Parâmetros típicos: amplitude, frequência, fase, offset, etc.
void signal_gen(float amplitude,
                float freq,
                float phase,
                float offset,
                float t,
                float *y_alpha,
                float *y_beta);

// ============================================================================
// Gerador de Referência (RefGen) – estrutura e defaults
// ============================================================================

// Valores padrão de inicialização do gerador de referência
// (usado para declarar DCL_REFGEN rgen = DCL_REFGEN_DEFAULTS;)
#define DCL_REFGEN_DEFAULTS { \
    0.0f,  0.0f,          /* amtgt, aminc */        \
    0.0f,  0.0f,          /* fmtgt, fminc */        \
    0.0f,  0.0f,  1.0f,   /* thinc, ts, umax */     \
   -1.0f,  2.0f*M_PI*60.0f, 0.0f, 0.0f, 0.0f,       \
    0.0f,  0.0f,  0.0f,  0.0f,                      \
    FINISHED                                             \
}

// Estrutura do gerador de referência
// Gera duas componentes senoidais (ya, yb), em quadratura, a partir de
// amplitude e frequência com rampa.
typedef volatile struct dcl_refgen {
  // Parâmetros de alvo e incrementos
    float32_t   amtgt;      //!< Amplitude alvo
    float32_t   aminc;      //!< Incremento de amplitude (por amostra)
    float32_t   fmtgt;      //!< Frequência alvo (rad/s)
    float32_t   fminc;      //!< Incremento de frequência (por amostra)
  // Parâmetros de fase / discretização
    float32_t   thinc;      //!< Incremento angular (não usado diretamente aqui)
    float32_t   ts;         //!< Período de amostragem (s)
  // Limites de saída (não usados explicitamente no run_Refgen atual)
    float32_t   umax;       //!< Máximo valor admissível de saída
    float32_t   umin;       //!< Mínimo valor admissível de saída
  // Parâmetros de referência nominal e estado dinâmico
    float32_t   freq_nom;   //!< Frequência nominal (rad/s)
    float32_t   ampl;       //!< Amplitude dinâmica (em rampa)
    float32_t   freq;       //!< Frequência dinâmica (em rampa)
    float32_t   freqtgt;    //!< Frequência alvo (cópia de fmtgt, para clareza)
  // Ângulos instantâneos das duas fases (rad)
    float32_t   theta;      //!< Ângulo fase A (rad)
    float32_t   thetb;      //!< Ângulo fase B (rad)
  // Saídas senoidais (alpha/beta ou fase A/B)
    float32_t   ya;         //!< Saída fase A
    float32_t   yb;         //!< Saída fase B
  // Status da rampa
    incStatus   status;     //!< INCREASING, DOWNING, FINISHED
  // Ponteiro para estrutura de suporte (não utilizada aqui)
    // DCL_CSS  *css;

} DCL_REFGEN;

// ============================================================================
// Funções inline: reset, configuração e execução do RefGen
// ============================================================================

/**
 * @brief Reseta o gerador de referência para estado inicial
 *
 * Saídas e variáveis internas vão para zero, e status = FINISHED.
 */
static inline void DCL_resetRefgen(DCL_REFGEN *p)
{
    p->ampl   = 0.0f;
    p->freq   = 0.0f;
    p->theta  = 0.0f;
    p->thetb  = 0.0f;
    p->thinc  = 0.0f;
    p->ya     = 0.0f;
    p->yb     = 0.0f;
  p->status = FINISHED;
  // Limites padrão da saída (podem ser ajustados externamente)
    p->umax   = 0.707f;
    p->umin   = 0.707f;
}

/**
 * @brief Configura o RefGen para executar uma rampa de amplitude e frequência.
 *
 * @param p            Ponteiro para estrutura do RefGen
 * @param final_ampl   Amplitude final desejada
 * @param freq_nom     Frequência nominal (rad/s) – usada como referência
 * @param final_freq   Frequência final desejada (rad/s)
 * @param ramp_time    Tempo de rampa (s) até atingir amplitude/frequência finais
 * @param sample_time  Período de amostragem (s)
 *
 * A função ajusta aminc e fminc para que, após ramp_time, a amplitude e
 * frequência atinjam final_ampl e final_freq. Também define o status como
 * INCREASING ou DOWNING, dependendo da direção da rampa.
 */
static inline void DCL_setRefgen(DCL_REFGEN *p,
                                 float32_t final_ampl,
                                 float32_t freq_nom,
                                 float32_t final_freq,
                                 float32_t ramp_time,
                                 float32_t sample_time)
{
    p->amtgt   = final_ampl;
    p->freqtgt = final_freq;
  // Cálculo dos incrementos de amplitude e frequência por amostra
    float32_t steps = ramp_time / sample_time;
    if (steps <= 0.0f) {
        // Se o tempo de rampa for inválido, aplica diretamente o alvo
        p->ampl = final_ampl;
        p->freq = final_freq;
        p->aminc = 0.0f;
        p->fminc = 0.0f;
        p->status = FINISHED;
    } else {
        p->aminc = (final_ampl - p->ampl) / steps;
        p->fminc = (final_freq - p->freq) / steps;
      // Define o sentido da rampa
        if (final_ampl > p->ampl) {
            p->status = INCREASING;
        } else if (final_ampl < p->ampl) {
            p->status = DOWNING;
        } else {
            // Amplitude já no alvo; verifica apenas frequência
            if (final_freq != p->freq) {
                p->status = (final_freq > p->freq) ? INCREASING : DOWNING;
            } else {
                p->status = FINISHED;
            }
        }
    }
  p->freq_nom = freq_nom;
    p->ts       = sample_time;
}

/**
 * @brief Executa o passo de atualização do gerador de referência.
 *
 * Atualiza amplitude, frequência, ângulos e escreve V_alpha/V_beta.
 * Deve ser chamada a cada período de amostragem (ex.: dentro da ISR do Timer0).
 *
 * @param p       Ponteiro para o RefGen
 * @param V_alpha Ponteiro para componente alfa da tensão de referência
 * @param V_beta  Ponteiro para componente beta da tensão de referência
 */
static inline void run_Refgen(DCL_REFGEN *p,
                              float *V_alpha,
                              float *V_beta)
{
    // Atualiza amplitude e frequência de acordo com status da rampa
    if (p->status == INCREASING) {
        p->ampl += p->aminc;
        p->freq += p->fminc;
      if (p->ampl >= p->amtgt) {
            p->ampl   = p->amtgt;
            p->freq   = p->freqtgt;
            p->status = FINISHED;
        }
    }
    else if (p->status == DOWNING) {
        p->ampl += p->aminc;
        p->freq += p->fminc;
      if (p->ampl <= p->amtgt) {
            p->ampl   = p->amtgt;
            p->freq   = p->freqtgt;
            p->status = FINISHED;
        }
    }
  // Integra ângulo das duas fases (A e B)
    p->theta += p->freq * p->ts;
    p->thetb += p->freq * p->ts;
  // Mantém ângulo dentro de [0, 2π)
    if (p->theta >= 2.0f*M_PI) {
        p->theta -= 2.0f*M_PI;
    }
    if (p->thetb >= 2.0f*M_PI) {
        p->thetb -= 2.0f*M_PI;
    }
  // Gera as componentes alfa/beta a partir de amplitude e ângulo
    *V_alpha = p->ampl * cosf(p->theta);
    *V_beta  = p->ampl * sinf(p->theta);
  /*
    // Modos de calibração (se forem reativados no futuro):
    if (p->status == CALIBRATING_ALPHA) {
        *V_alpha = 1.0f;
        *V_beta  = 0.0f;
    }
    if (p->status == CALIBRATING_BETA) {
        *V_alpha = 0.0f;
        *V_beta  = 1.0f;
    }
    */
}

#endif /* SVPWM_H_ */