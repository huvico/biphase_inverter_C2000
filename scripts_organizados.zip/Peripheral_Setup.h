/*
 * Peripheral_Setup.h
 *
 * Descrição:
 *   Declarações e constantes de configuração dos periféricos do F28379D:
 *     - GPIO
 *     - PWM (ePWM)
 *     - ADC
 *     - DAC
 *     - eQEP
 *
 * Criado em: 28 de abr de 2022
 * Autor: Hudson
 */

#ifndef PERIPHERAL_SETUP_H_
#define PERIPHERAL_SETUP_H_

#include "F28x_Project.h"

// ============================================================================
// Parâmetros de temporização do driver (dead-time / turn-on / turn-off)
// ============================================================================
//
// Observação:
//   Removido o ';' do final das macros, pois:
//     #define RISE_TIME 350;
//   expande para "350;" dentro de expressões e causa problemas de compilação.
//   O correto é sem ';'.
//
#define RISE_TIME   350U    // Tempo de subida (ns ou ciclos, conforme uso no .c)
#define FALL_TIME   350U    // Tempo de descida

// ============================================================================
// Configuração do período de chaveamento (PWM)
// ============================================================================
//
// SWITCH_PERIOD define o valor de TBPRD do ePWM, relacionado à frequência de chaveamento.
// Comentário original:
//   SWITCH_PERIOD = 200000/(4*f_switch);  // se up-down
//   ou SWITCH_PERIOD = 200000/(2*f_switch); // se modo up
//   onde f_switch está em kHz
//
// Aqui mantemos um valor fixo (5000) e a lógica detalhada fica no .c.
//
#define SWITCH_PERIOD  5000U

// ============================================================================
// eQEP: configuração geral
// ============================================================================
//
// Valor máximo de contagem do eQEP (usado para cálculo de delta_pos com wrap-around).
//
#define eQEP_max_count  0xFFFFFFFFUL

// ============================================================================
// Protótipos de funções de configuração de periféricos
// ============================================================================
//
// Essas funções devem ser implementadas em Peripheral_Setup.c e chamadas no main:
//   - Setup_GPIO():  configura pinos (PWM, ADC, eQEP, etc.)
//   - Setup_PWM():   configura módulos ePWM (frequência, dead-time, ações, TZ, etc.)
//   - Setup_ADC():   configura módulos ADC (canais, triggers, interrupções)
//   - Setup_DAC():   (se utilizado) configura DAC interno para debug ou referência
//   - Setup_eQEP():  configura módulo eQEP para medição de posição/velocidade
//

void Setup_GPIO(void);
void Setup_PWM(void);
void Setup_ADC(void);
void Setup_DAC(void);
void Setup_eQEP(void);

#endif /* PERIPHERAL_SETUP_H_ */