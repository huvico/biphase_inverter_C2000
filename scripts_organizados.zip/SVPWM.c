/*
 * SVPWM.c
 *
 * Space Vector PWM functions to calculate duty cycle:
 *   - svpwm_bi: SVPWM para motor bifásico / monofásico assimétrico
 *   - svpwm   : SVPWM trifásico convencional
 *
 * Criado em: 28 de abr de 2022
 * Autor: Hudson
 */

#include "SVPWM.h"

// ============================================================================
// Variáveis internas deste módulo
// ============================================================================
//
// Nota: mantidas como 'static' para limitar o escopo a este arquivo.
// Elas não precisam ser globais no projeto inteiro.
//
// U1, U2   : módulos dos vetores ativos utilizados no setor
// theta1, theta2 : ângulos (rad) dos vetores ativos do setor
// t1, t2   : tempos relativos de aplicação dos vetores ativos
// Uref     : módulo da tensão de referência (|V_alpha + j V_beta|)
// toff     : tempo relativo de vetor zero (off)
// setor    : identifica o setor do espaço vetorial
// k        : termo auxiliar na forma trifásica

static float U1   = 1.0f;
static float U2   = 1.0f;
static float teta1 = 2.0f * M_PI;
static float teta2 = 1.5f * M_PI;

static float t1   = 0.0f;
static float t2   = 0.0f;
static float Uref = 0.0f;
static float toff = 0.0f;
static float k    = 0.0f;

static int setor  = 0;

// Variáveis globais usadas em outros módulos (declaradas em Variables.c)
extern float V_alpha;
extern float V_beta;
extern float teta;

// ============================================================================
// SVPWM bifásico (motor bifásico / monofásico assimétrico)
// ============================================================================
//
// Parâmetros:
//   teta   : ponteiro para ângulo de referência (rad) – já calculado externamente
//   V_alpha, V_beta : componentes alfa/beta da tensão de referência
//   wma, wmb, wmc   : saídas de modulação normalizadas (0..1) para as 3 fases
//
// Observação:
//   O algoritmo está adaptado para um "espaço vetorial assimétrico", típico
//   de motores bifásicos (ou monofásicos com enrolamento auxiliar).
//
void svpwm_bi(float *teta,
              float *V_alpha,
              float *V_beta,
              float *wma,
              float *wmb,
              float *wmc)
{
    // Definições padrão (caso nenhum setor 1..5 seja selecionado)
    setor = 6;
    U1    = 1.0f;
    U2    = 1.0f;
    teta1 = 0.0f;
    teta2 = 270.0f * M_PI / 180.0f;
  // Seleção de setor no espaço vetorial bifásico assimétrico
    // A região de [0, 3π/2) é separada em 5 setores principais;
    // o setor 6 é um "default" para o restante.
    if ((*teta >= 0.0f) && (*teta < M_PI / 4.0f))
    {
        U1    = 1.0f;
        U2    = sqrtf(2.0f);
        teta1 = 0.0f;
        teta2 = M_PI / 4.0f;
        setor = 1;
    }
    if ((*teta >= M_PI / 4.0f) && (*teta < M_PI / 2.0f))
    {
        U1    = 1.0f;
        U2    = sqrtf(2.0f);
        teta1 = M_PI / 2.0f;
        teta2 = M_PI / 4.0f;
        setor = 2;
    }
    if ((*teta >= M_PI / 2.0f) && (*teta < M_PI))
    {
        U1    = 1.0f;
        U2    = 1.0f;
        teta1 = M_PI / 2.0f;
        teta2 = M_PI;
        setor = 3;
    }
    if ((*teta >= M_PI) && (*teta < 5.0f * M_PI / 4.0f))
    {
        U1    = sqrtf(2.0f);
        U2    = 1.0f;
        teta1 = 1.25f * M_PI;  // M_PI * 1.25
        teta2 = M_PI;
        setor = 4;
    }
    if ((*teta >= 5.0f * M_PI / 4.0f) && (*teta < 3.0f * M_PI / 2.0f))
    {
        U1    = sqrtf(2.0f);
        U2    = 1.0f;
        teta1 = 1.25f * M_PI;
        teta2 = 1.5f * M_PI;
        setor = 5;
    }
  // Módulo da tensão de referência
    Uref = sqrtf((*V_alpha) * (*V_alpha) + (*V_beta) * (*V_beta));
  // Cálculo dos tempos relativos de vetores ativos (t1, t2)
    // As expressões usam relações trigonométricas com os ângulos dos vetores U1, U2
    t1 = (Uref / U1) * (sinf(teta2 - *teta) / sinf(teta2 - teta1));
    t2 = (Uref / U2) * (sinf(*teta - teta1) / sinf(teta2 - teta1));
  // Tempo relativo de vetor zero
    toff = 1.0f - t1 - t2;
  // Cálculo dos duty cycles para cada setor
    // Observação: as fórmulas estão mantidas exatamente como no código original
    if (setor == 1)
    {
        *wma = 1.0f - toff / 2.0f;
        *wmb = 1.0f - toff / 2.0f - t1 - t2;
        *wmc = 1.0f - toff / 2.0f - t1;
    }
    if (setor == 2)
    {
        *wma = 1.0f - toff / 2.0f - t1;
        *wmb = 1.0f - toff / 2.0f - t1 - t2;
        *wmc = 1.0f - toff / 2.0f;
    }
    if (setor == 3)
    {
        *wma = 1.0f - toff / 2.0f - t1 - t2;
        *wmb = 1.0f - toff / 2.0f - t1;
        *wmc = 1.0f - toff / 2.0f;
    }
    if (setor == 4)
    {
        *wma = 1.0f - toff / 2.0f - t1 - t2;
        *wmb = 1.0f - toff / 2.0f;
        *wmc = 1.0f - toff / 2.0f - t1;
    }
    if (setor == 5)
    {
        *wma = 1.0f - toff / 2.0f - t1;
        *wmb = 1.0f - toff / 2.0f;
        *wmc = 1.0f - toff / 2.0f - t1 - t2;
    }
    if (setor == 6)
    {
        *wma = 1.0f - toff / 2.0f;
        *wmb = 1.0f - toff / 2.0f - t1;
        *wmc = 1.0f - toff / 2.0f - t1 - t2;
    }
}

// ============================================================================
// SVPWM trifásico convencional
// ============================================================================
//
// Parâmetros:
//   teta   : ponteiro para ângulo de referência (rad) – será calculado aqui
//   V_alpha, V_beta : componentes alfa/beta da tensão de referência
//   wma, wmb, wmc   : saídas de modulação normalizadas (0..1) para as 3 fases
//
void svpwm(float *teta,
           float *V_alpha,
           float *V_beta,
           float *wma,
           float *wmb,
           float *wmc)
{
    // Módulo da tensão de referência
    Uref = sqrtf((*V_alpha) * (*V_alpha) + (*V_beta) * (*V_beta));
  // Cálculo de teta a partir de V_alpha e V_beta
    if (Uref == 0.0f)
    {
        *teta = 0.0f;
    }
    else
    {
        *teta = acosf(fabsf((*V_alpha) / Uref));
    }
  // Ajuste do quadrante de teta
    if ((*V_alpha < 0.0f) && (*V_beta > 0.0f))
    {
        *teta = M_PI - *teta;
    }
    if ((*V_alpha < 0.0f) && (*V_beta < 0.0f))
    {
        *teta = M_PI + *teta;
    }
    if ((*V_alpha > 0.0f) && (*V_beta < 0.0f))
    {
        *teta = 2.0f * M_PI - *teta;
    }
  // Determinação do setor em SVPWM trifásico tradicional
    if ((*teta >= 0.0f) && (*teta < 60.0f * M_PI / 180.0f))
    {
        teta1 = 0.0f;
        teta2 = 60.0f * M_PI / 180.0f;
        setor = 1;
    }
    if ((*teta >= 60.0f * M_PI / 180.0f) && (*teta < 120.0f * M_PI / 180.0f))
    {
        teta1 = 60.0f * M_PI / 180.0f;
        teta2 = 120.0f * M_PI / 180.0f;
        setor = 2;
    }
    if ((*teta >= 120.0f * M_PI / 180.0f) && (*teta < M_PI))
    {
        teta1 = 120.0f * M_PI / 180.0f;
        teta2 = M_PI;
        setor = 3;
    }
    if ((*teta >= M_PI) && (*teta < 240.0f * M_PI / 180.0f))
    {
        teta1 = M_PI;
        teta2 = 240.0f * M_PI / 180.0f;
        setor = 4;
    }
    if ((*teta >= 240.0f * M_PI / 180.0f) && (*teta < 300.0f * M_PI / 180.0f))
    {
        teta1 = 240.0f * M_PI / 180.0f;
        teta2 = 300.0f * M_PI / 180.0f;
        setor = 5;
    }
    if ((*teta >= 300.0f * M_PI / 180.0f) && (*teta <= 2.0f * M_PI))
    {
        teta1 = 300.0f * M_PI / 180.0f;
        teta2 = 2.0f * M_PI;
        setor = 6;
    }
  // Termo auxiliar 'k' (determinante das projeções dos vetores ativos)
    k = cosf(teta1) * sinf(teta2) - cosf(teta2) * sinf(teta1);
  // Cálculo dos tempos relativos de vetores ativos (t1, t2)
    t1 = (sinf(teta2) * (*V_alpha)) / k - (cosf(teta2) * (*V_beta)) / k;
    t2 = (-sinf(teta1) * (*V_alpha) / k) + (cosf(teta1) * (*V_beta) / k);
  // Tempo relativo de vetor zero
    toff = 1.0f - t1 - t2;
  // Cálculo dos duty cycles para cada setor
    if (setor == 1)
    {
        *wma = t1 + t2 + toff / 2.0f;
        *wmb = t2 + toff / 2.0f;
        *wmc = toff / 2.0f;
    }
    if (setor == 2)
    {
        *wma = t1 + toff / 2.0f;
        *wmb = t1 + t2 + toff / 2.0f;
        *wmc = toff / 2.0f;
    }
    if (setor == 3)
    {
        *wma = toff / 2.0f;
        *wmb = t1 + t2 + toff / 2.0f;
        *wmc = t2 + toff / 2.0f;
    }
    if (setor == 4)
    {
        *wma = toff / 2.0f;
        *wmb = t1 + toff / 2.0f;
        *wmc = t1 + t2 + toff / 2.0f;
    }
    if (setor == 5)
    {
        *wma = t2 + toff / 2.0f;
        *wmb = toff / 2.0f;
        *wmc = t1 + t2 + toff / 2.0f;
    }
    if (setor == 6)
    {
        *wma = t1 + t2 + toff / 2.0f;
        *wmb = toff / 2.0f;
        *wmc = t1 + toff / 2.0f;
    }
}